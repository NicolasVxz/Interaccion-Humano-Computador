<%-- 
    Document   : ubicaciones
    Created on : 28 oct. 2026, 11:46:32
    Author     : josep
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("usuario") == null) {
        response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
        return;
    }
    java.util.List<Object[]> alertas = (java.util.List<Object[]>) request.getAttribute("alertas");
    java.util.List<Object[]> movimientos = (java.util.List<Object[]>) request.getAttribute("movimientos");
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>UBICACIONES</title>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/estilos-ubicacion.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-B/GM4XqrwHnWXNOWMbloTmrYXZg10cakYGmpfsR/bbzQ6JAJI4ihuyADKLnBgrCe" crossorigin="anonymous">
        <script type="module" src="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-1a/pXj49ZQ1aHEmrJ+gMw1otqoVsYwlEnlD8mIfY2TV03r20Y0CN7uqx1tQogjPL" crossorigin="anonymous"></script>         
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/tema-oscuro.css"/>
        <script src="${pageContext.request.contextPath}/JS/accesibilidad.js"></script>
    </head>
    <body>
        <header class="encabezado">
            <div class="logo">
                <span class="dhl"> DHL </span>
                <span class="sede"> SUPPLY CHAIN </span>          
            </div>
            <div class="encabezado-usuario">
                <span>👤 ${sessionScope.nombre}</span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-salir"> Salir </a>
            </div>
        </header>
            <aside class="lateral">
                <div class="lista-enlaces"></div>
                <h2 class="subtitulo"> SISTEMAS DE INVENTARIO </h2>
                <a href="${pageContext.request.contextPath}/HomeServlet" class="lista-enlaces-item">HOME</a>
                <a href="${pageContext.request.contextPath}/RegistrarServlet" class="lista-enlaces-item">REGISTRAR</a>
                <a href="${pageContext.request.contextPath}/MovimientoServlet" class="lista-enlaces-item">MOVIMIENTO</a>
                <a href="${pageContext.request.contextPath}/PAGES/ubicacion.jsp" class="lista-enlaces-item activo">UBICACIONES</a>
                <a href="${pageContext.request.contextPath}/ReporteServlet" class="lista-enlaces-item">REPORTES</a>
                <a href="${pageContext.request.contextPath}/PAGES/configuracion.jsp" class="lista-enlaces-item">CONFIGURACION</a>            
            </aside>        
            
            <section class="guia">
                <h3 class="guiatext">Guia para conocimiento de ubicaciones:</h3>
            <div class="accordion">
                
              <details class="accordion-item" name="accordionNested" open>
                <summary class="accordion-header">
                    <b>ALMACEN PRINCIPAL</b>
                  <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                </summary>
                <div class="accordion-body">
                  <strong>AP</strong> 
                  <div class="accordion mt-3">
                    <details class="accordion-item" name="accordionNestedInner" open>
                      <summary class="accordion-header">
                          <b>RACK A1</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                          <ul>A1-01-1</ul>
                          <ul>A1-02-1</ul>            
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK A2</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>A2-01-1</ul>
                        <ul>A2-02-1</ul>
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK A3</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>A3-01-1</ul>
                        <ul>A3-02-1</ul>
                      </div>
                    </details>
                  </div>
                </div>
              </details>


              


             <details class="accordion-item" name="accordionNested" open>
                <summary class="accordion-header">
                    <b>ALMACEN LUBRICANTES</b>
                  <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                </summary>
                <div class="accordion-body">
                  <strong>LUB</strong> 
                  <div class="accordion mt-3">
                    <details class="accordion-item" name="accordionNestedInner" open>
                      <summary class="accordion-header">
                        <b>RACK 01</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                          <ul>01-01-0001-0</ul>
                          <ul>01-02-0001-0</ul>            
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK 02</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>02-01-0001-0</ul>
                        <ul>02-02-0001-0</ul>
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK 03</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>03-01-0001-0</ul>
                        <ul>03-02-0001-0</ul>
                      </div>
                    </details>
                  </div>
                </div>
              </details>
                
                
                <details class="accordion-item" name="accordionNested" open>
                <summary class="accordion-header">
                    <b>COMBUSTIBLE</b>
                  <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                </summary>
                <div class="accordion-body">
                  <strong>CB</strong> 
                  <div class="accordion mt-3">
                    <details class="accordion-item" name="accordionNestedInner" open>
                      <summary class="accordion-header">
                        <b>RACK 01</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                          <ul>01-01-0001-0</ul>
                          <ul>01-02-0001-0</ul>
                          <ul>01-03-0001-0</ul> 
                          <ul>01-01-0002-0</ul>
                          <ul>01-02-0002-0</ul>
                          <ul>01-03-0002-0</ul> 
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK 02</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                            <ul>02-01-0001-0</ul>
                            <ul>02-02-0001-0</ul>
                             <ul>02-03-0001-0</ul> 
                            <ul>02-01-0002-0</ul>
                            <ul>02-02-0002-0</ul>
                            <ul>02-03-0002-0</ul> 
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK 03</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>03-01-0001-0</ul>
                            <ul>03-02-0001-0</ul>
                             <ul>03-03-0001-0</ul> 
                            <ul>03-01-0002-0</ul>
                            <ul>03-02-0002-0</ul>
                            <ul>03-03-0002-0</ul>
                      </div>
                    </details>
                  </div>
                </div>
              </details>
                
                
                <details class="accordion-item" name="accordionNested" open>
                <summary class="accordion-header">
                    <b>ALMACEN SOBRE DIMENSIONADO 2</b>
                  <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                </summary>
                <div class="accordion-body">
                  <strong>SBA2</strong> 
                  <div class="accordion mt-3">
                    <details class="accordion-item" name="accordionNestedInner" open>
                      <summary class="accordion-header">
                        <b>RACK A</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                          <ul>A-01</ul>
                          <ul>A-02</ul>            
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK B</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>B-01</ul>
                        <ul>B-02</ul>
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>RACK C</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>C-01</ul>
                        <ul>C-02</ul>
                      </div>
                    </details>
                  </div>
                </div>
              </details>
                
                
                 <details class="accordion-item" name="accordionNested" open>
                <summary class="accordion-header">
                    <b>ALMACEN SOBRE DIMENSIONADO 3</b>
                  <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                </summary>
                <div class="accordion-body">
                  <strong>SBA3</strong> 
                  <div class="accordion mt-3">
                    <details class="accordion-item" name="accordionNestedInner" open>
                      <summary class="accordion-header">
                        <b>FRENOS </b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                          <ul>FRENOS - PISO</ul>                                    
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>DECORATIVO-1</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>A-01</ul>
                        <ul>B-01</ul>
                        <ul>C-01</ul>
                        <ul>D-01</ul>
                        <ul>E-01</ul>
                        <ul>F-01</ul>
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>DECORATIVO-2</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>A-02</ul>
                        <ul>B-02</ul>
                        <ul>C-02</ul>
                        <ul>D-02</ul>
                        <ul>E-02</ul>
                        <ul>F-02</ul>
                      </div>
                    </details>
                  </div>
                </div>
              </details>
                
                
                 <details class="accordion-item" name="accordionNested" open>
                <summary class="accordion-header">
                    <b>ALMACEN OXIGENO</b>
                  <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                </summary>
                <div class="accordion-body">
                  <strong>OXI</strong> 
                  <div class="accordion mt-3">
                    <details class="accordion-item" name="accordionNestedInner" open>
                      <summary class="accordion-header">
                        <b>AREA-O </b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                          <ul>OXIGENO - PISO</ul>                                    
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>OXIGENO-1</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>A-01</ul>
                        <ul>B-01</ul>
                        <ul>C-01</ul>                      
                      </div>
                    </details>
                    <details class="accordion-item" name="accordionNestedInner">
                      <summary class="accordion-header">
                        <b>OXIGENO-2</b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                        <ul>A-02</ul>
                        <ul>B-02</ul>
                        <ul>C-02</ul>
                      </div>
                    </details>
                  </div>
                </div>
              </details>

                
                 <details class="accordion-item" name="accordionNested" open>
                <summary class="accordion-header">
                    <b>ALMACEN CAUCHOS</b>
                  <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                </summary>
                <div class="accordion-body">
                  <strong>CAU</strong> 
                  <div class="accordion mt-3">
                    <details class="accordion-item" name="accordionNestedInner" open>
                      <summary class="accordion-header">
                        <b>AREA-CAUCHOS </b>
                        <svg class="accordion-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m2 5 6 6 6-6"/></svg>
                      </summary>
                      <div class="accordion-body">
                          <ul>CAUCHOS - PISO</ul>                                    
                      </div>
                    </details>       
                  </div>
                </div>
              </details>
                
                
            </div>
            </section> 
    </body>
</html>
