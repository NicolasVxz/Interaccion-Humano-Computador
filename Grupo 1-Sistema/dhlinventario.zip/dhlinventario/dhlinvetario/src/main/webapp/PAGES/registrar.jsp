<%-- 
    Document   : registrar
    Created on : 28 oct. 2026, 11:45:13
    Author     : josep
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List, com.maven.dhlinvetario.be.Materialbe, com.maven.dhlinvetario.util.Html"%>
<%
    // 1. Sin sesion -> al login
    if (session.getAttribute("usuario") == null) {
        response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
        return;
    }
    // 2. Si abrieron el JSP directo (sin pasar por el servlet) los mandamos al servlet
    if (request.getAttribute("recientes") == null) {
        response.sendRedirect(request.getContextPath() + "/RegistrarServlet");
        return;
    }

    List<Materialbe> recientes = (List<Materialbe>) request.getAttribute("recientes");

    // Mensaje que manda el servlet (verde si salio bien, rojo si hubo error)
    String mensaje = (String) request.getAttribute("mensaje");
    boolean esOk = Boolean.TRUE.equals(request.getAttribute("esOk"));

    // Si hubo error, se vuelve a poner lo que el usuario escribio
    String vBarcode  = request.getParameter("Barcode");
    String vPart     = request.getParameter("PartNumber");
    String vNombre   = request.getParameter("PartName");
    String vCantidad = request.getParameter("Cantidad");
    String vSimbolo  = request.getParameter("Simbolo");
    String vUbi      = request.getParameter("Ubi");
    String vMinimo   = request.getParameter("Minimo");
    if (esOk) { vBarcode = vPart = vNombre = vCantidad = vSimbolo = vUbi = vMinimo = null; }

    java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm");
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>REGISTRAR</title>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/estilos-registro.css"/>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/tema-oscuro.css"/>
        <script src="${pageContext.request.contextPath}/JS/accesibilidad.js"></script>
    </head>
    <body>
        <header class="encabezado">
            <div class="logo">
                <span class="dhl"> DHL </span>
                <span class="sede"> SUPPLY CHAIN </span>
            </div>
            <div class="encabezado-usuario">
                <span>👤 ${sessionScope.nombre}</span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-salir"> Salir </a>
            </div>
        </header>

        <aside class="lateral">
            <h2 class="subtitulo"> SISTEMAS DE INVENTARIO </h2>
            <a href="${pageContext.request.contextPath}/HomeServlet" class="lista-enlaces-item">HOME</a>
            <a href="${pageContext.request.contextPath}/RegistrarServlet" class="lista-enlaces-item activo">REGISTRAR</a>
            <a href="${pageContext.request.contextPath}/MovimientoServlet" class="lista-enlaces-item">MOVIMIENTO</a>
            <a href="${pageContext.request.contextPath}/PAGES/ubicacion.jsp" class="lista-enlaces-item">UBICACIONES</a>
            <a href="${pageContext.request.contextPath}/ReporteServlet" class="lista-enlaces-item">REPORTES</a>
            <a href="${pageContext.request.contextPath}/PAGES/configuracion.jsp" class="lista-enlaces-item">CONFIGURACION</a>
        </aside>

        <main class="panel">
            <h1>Registrar material</h1>
            <p class="texto-suave">DA DE ALTA UN MATERIAL NUEVO EN EL ALMACEN</p>

            <% if (mensaje != null) { %>
                <p class="aviso <%= esOk ? "aviso-ok" : "aviso-error" %>"><%= Html.esc(mensaje) %></p>
            <% } %>

            <section class="caja">
                <h3>Datos del material</h3>
                <form action="${pageContext.request.contextPath}/RegistrarServlet" method="post" class="formulario" id="formRegistrar">

                    <div class="campo campo-ancho">
                        <label for="Barcode">Codigo de barras</label>
                        <input type="text" id="Barcode" name="Barcode" maxlength="50"
                               value="<%= Html.esc(vBarcode) %>"
                               placeholder="Escanea o escribe el codigo" autocomplete="off" required autofocus>
                    </div>

                    <div class="campo">
                        <label for="PartNumber">Part Number</label>
                        <input type="text" id="PartNumber" name="PartNumber" maxlength="50"
                               value="<%= Html.esc(vPart) %>"
                               placeholder="Ej: PN-1001" autocomplete="off" required>
                    </div>

                    <div class="campo">
                        <label for="PartName">Nombre del material</label>
                        <input type="text" id="PartName" name="PartName" maxlength="120"
                               value="<%= Html.esc(vNombre) %>"
                               placeholder="Ej: Filtro de aceite" autocomplete="off" required>
                    </div>

                    <div class="campo">
                        <label for="Cantidad">Cantidad</label>
                        <input type="number" id="Cantidad" name="Cantidad" step="0.01" min="0" max="99999999.99"
                               value="<%= Html.esc(vCantidad) %>"
                               placeholder="0.00" required>
                    </div>

                    <div class="campo">
                        <label for="Simbolo">Unidad de medida</label>
                        <input type="text" id="Simbolo" name="Simbolo" maxlength="5"
                               value="<%= Html.esc(vSimbolo) %>"
                               placeholder="Ej: EA" autocomplete="off" required>
                    </div>

                    <div class="campo">
                        <label for="Ubi">Ubicacion</label>
                        <input type="text" id="Ubi" name="Ubi" maxlength="25"
                               value="<%= Html.esc(vUbi) %>"
                               placeholder="Ej: AP/A1-01-1" autocomplete="off" required>
                    </div>

                    <div class="campo">
                        <label for="Minimo">Stock minimo (opcional)</label>
                        <input type="number" id="Minimo" name="Minimo" step="0.01" min="0" max="99999999.99"
                               value="<%= Html.esc(vMinimo) %>"
                               placeholder="Avisar cuando baje de...">
                    </div>

                    <div class="acciones">
                        <button type="submit" class="btn-guardar">GUARDAR</button>
                        <button type="reset" class="btn-limpiar">LIMPIAR</button>
                    </div>
                </form>
            </section>

            <section class="caja">
                <h3>Ultimos materiales registrados</h3>
                <div class="tabla-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>Codigo de barras</th>
                                <th>Part Number</th>
                                <th>Material</th>
                                <th>Cantidad</th>
                                <th>Ubicacion</th>
                                <th>Registrado</th>
                                <th>Registrado por</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% if (recientes == null || recientes.isEmpty()) { %>
                                <tr><td colspan="7">Aun no hay materiales registrados.</td></tr>
                            <% } else {
                                   for (Materialbe m : recientes) { %>
                                <tr>
                                    <td><%= Html.esc(m.getBarcode()) %></td>
                                    <td><%= Html.esc(m.getPartNumber()) %></td>
                                    <td><%= Html.esc(m.getPartName()) %></td>
                                    <td><%= m.getCantidad().stripTrailingZeros().toPlainString() %> <%= Html.esc(m.getSimbolo()) %></td>
                                    <td><%= Html.esc(m.getUbi()) %></td>
                                    <td><%= fmt.format(m.getFechaRegistro()) %></td>
                                    <td><%= Html.esc(m.getNombreRegistro() != null ? m.getNombreRegistro() : m.getUsuarioRegistro()) %></td>
                                </tr>
                            <%     }
                               } %>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <script src="${pageContext.request.contextPath}/JS/logout.js"></script>
        <script src="${pageContext.request.contextPath}/JS/registrar.js"></script>
    </body>
</html>