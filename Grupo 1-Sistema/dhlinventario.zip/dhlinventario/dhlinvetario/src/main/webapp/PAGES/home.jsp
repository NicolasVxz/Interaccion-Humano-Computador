<%-- 
    Document   : configuracion
    Created on : 28 oct. 2026, 11:46:59
    Author     : josep
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("usuario") == null) {
        response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
        return;
    }
    
    java.util.List<Object[]> alertas = (java.util.List<Object[]>) request.getAttribute("alertas");
    java.util.List<Object[]> movimientos = (java.util.List<Object[]>) request.getAttribute("movimientos");
%>
<!DOCTYPE html>
 
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Home</title>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/estilos-home.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-B/GM4XqrwHnWXNOWMbloTmrYXZg10cakYGmpfsR/bbzQ6JAJI4ihuyADKLnBgrCe" crossorigin="anonymous">
        <script type="module" src="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-1a/pXj49ZQ1aHEmrJ+gMw1otqoVsYwlEnlD8mIfY2TV03r20Y0CN7uqx1tQogjPL" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/tema-oscuro.css"/>
        <script src="${pageContext.request.contextPath}/JS/accesibilidad.js"></script>
    </head>
    <body>
        <header class="encabezado">
            <div class="logo">
                <span class="dhl"> DHL </span>
                <span class="sede"> SUPPLY CHAIN </span>          
            </div>
            <div class="encabezado-usuario">
                <span>👤 ${sessionScope.nombre}</span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-salir"> Salir </a>
            </div>
        </header>
            <aside class="lateral">
                <div class="lista-enlaces"></div>
                <h2 class="subtitulo"> SISTEMAS DE INVENTARIO </h2>
                <a href="${pageContext.request.contextPath}/HomeServlet" class="lista-enlaces-item activo">HOME</a>
                <a href="${pageContext.request.contextPath}/RegistrarServlet" class="lista-enlaces-item">REGISTRAR</a>
                <a href="${pageContext.request.contextPath}/MovimientoServlet" class="lista-enlaces-item">MOVIMIENTO</a>
                <a href="${pageContext.request.contextPath}/PAGES/ubicacion.jsp" class="lista-enlaces-item">UBICACIONES</a>
                <a href="${pageContext.request.contextPath}/ReporteServlet" class="lista-enlaces-item">REPORTES</a>
                <a href="${pageContext.request.contextPath}/PAGES/configuracion.jsp" class="lista-enlaces-item">CONFIGURACION</a>            
            </aside>
            <main class="panel">
                <h1><span id="saludo"> HOLA</span>, ${sessionScope.nombre}</h1>
                <p class="texto-suave">UNA VISTA CLARA DE TU OPERACION EN ALMACEN <b> ( <span class="fe" id="FECHA"></span> ) </b> </p>
                <p class="aviso-error">${errorBD}</p>
                <section class="tarjetas">
                    <div class="tarjeta">
                        <span class="tarjeta-titulo"> MATERIALES </span>
                        <span class="tarjeta-numero">${partNumbers}</span>
                    </div>
                    <div class="tarjeta">
                        <span class="tarjeta-titulo">TOTAL UNIDADES</span>
                        <span class="tarjeta-numero">${totalUnidades}</span>
                    </div>
                    <div class="tarjeta">
                        <span class="tarjeta-titulo">INGRESOS DE HOY</span>
                        <span class="tarjeta-numero">${ingresosHoy}</span>
                    </div>
                    <div class="tarjeta">
                        <span class="tarjeta-titulo">SALIDAS DE HOY</span>
                        <span class="tarjeta-numero">${salidasHoy}</span>
                    </div>
                </section>
                <section class="dos-columnas">
                    <div class="caja">
                        <h3>Requieren atención</h3>
                        <ul class="alertas">
                            <% if (alertas == null || alertas.isEmpty()) { %>
                                <li class="todo-bien">Todo bajo control. Sin alertas de stock.</li>
                            <% } else {
                                   for (Object[] a : alertas) { %>
                                <li>
                                    <b><%= com.maven.dhlinvetario.util.Html.esc(a[0]) %></b><br>
                                    <small><%= a[1] %> unidades / mínimo <%= a[2] %></small>
                                </li>
                            <%     }
                               } %>
                        </ul>
                    </div>

                    <div class="caja">
                        <h3>Actividad reciente</h3>
                        <table>
                            <thead>
                                <tr><th>Fecha</th><th>Tipo</th><th>Material</th><th>Cant.</th></tr>
                            </thead>
                            <tbody>
                                <% if (movimientos == null || movimientos.isEmpty()) { %>
                                    <tr><td colspan="4">Aún no hay movimientos.</td></tr>
                                <% } else {
                                       for (Object[] m : movimientos) {
                                           boolean esEntrada = "ENTRADA".equals(String.valueOf(m[1])); %>
                                    <tr>
                                        <td><%= m[0] %></td>
                                        <td>
                                            <span class="badge <%= esEntrada ? "entrada" : "salida" %>">
                                                <%= esEntrada ? "Entrada" : "Salida" %>
                                            </span>
                                        </td>
                                        <td><%= com.maven.dhlinvetario.util.Html.esc(m[2]) %></td>
                                        <td><%= esEntrada ? "+" : "-" %><%= m[3] %></td>
                                    </tr>
                                <%     }
                                   } %>
                            </tbody>
                        </table>
                    </div>
                </section>
            </main>
            <script src="${pageContext.request.contextPath}/JS/saludar.js"></script>
            <script src="${pageContext.request.contextPath}/JS/fechahoy.js"></script>
            <script src="${pageContext.request.contextPath}/JS/logout.js"></script>

    </body>
</html>
