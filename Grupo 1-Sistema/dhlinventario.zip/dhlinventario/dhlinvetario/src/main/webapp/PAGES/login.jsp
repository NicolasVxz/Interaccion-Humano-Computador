<%-- 
    Document   : configuracion
    Created on : 28 oct. 2026, 11:46:59
    Author     : josep
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>DHL-LOGIN</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/estilos-login.css"/>
        </head>
 
    <body>

    <div class="login-contenedor">
        <div class="left">
            <h1>DHL</h1>
            <h2>SUPPLY CHAIN</h2>
            <div class="line"></div>
            <p>
                Sistema de gestión de mantenimiento
                para la administración y seguimiento
                de equipos y operaciones.
            </p>
        </div>

        <div class="right">
            <h2>Iniciar sesión</h2>
            <p class="subtitulo">
                Ingresa tus credenciales para continuar
            </p>
            
            <% if ("1".equals(request.getParameter("error"))) { %>
                 <p class="mensaje-error">Usuario o contraseña incorrectos</p>
            <% } %>   
            
            <form action="${pageContext.request.contextPath}/LoginServlet" method="post">
            <!--form action="LoginServlet" method="post"-->
                <div class="input-group">
                    <label>Usuario</label>
                    <input
                        type="text"
                        name="Usuario"
                        placeholder="Ingrese su usuario"
                        required>
                </div>
                <div class="input-group">
                    <label>Contraseña</label>
                    <input
                        type="password"
                        name="Clave"
                        placeholder="Ingrese su contraseña"
                        required>
                </div>
                <label><input class="mostrar-contra" type="checkbox" id="verClave"> Mostrar contraseña</label>
                <hr>
                <button type="submit" class="btn-login">
                     INICIAR SESION
                </button>            
            </form>
        </div>
    </div>
          <script src="${pageContext.request.contextPath}/JS/login.js"></script>  
</body>
</html>
