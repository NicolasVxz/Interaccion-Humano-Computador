<%-- 
     Document   : registrar
    Created on : 28 oct. 2026, 11:45:13
    Author     : josep
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List, java.math.BigDecimal, com.maven.dhlinvetario.be.Materialbe, com.maven.dhlinvetario.be.Movimientobe, com.maven.dhlinvetario.util.Html"%>
<%
    if (session.getAttribute("usuario") == null) {
        response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
        return;
    }
    // Si abrieron el JSP directo (sin pasar por el servlet) los mandamos al servlet
    String reporte = (String) request.getAttribute("reporte");
    if (reporte == null) {
        response.sendRedirect(request.getContextPath() + "/ReporteServlet");
        return;
    }

    List<Materialbe> stock = (List<Materialbe>) request.getAttribute("listaStock");
    List<Movimientobe> movs = (List<Movimientobe>) request.getAttribute("listaMovimientos");
    String mensaje = (String) request.getAttribute("mensaje");

    String fDesde = (String) request.getAttribute("fDesde");
    String fHasta = (String) request.getAttribute("fHasta");
    String fTipo  = (String) request.getAttribute("fTipo");

    boolean esStock = "stock".equals(reporte);
    boolean esBajo  = "bajo".equals(reporte);
    boolean esMovs  = "movimientos".equals(reporte);

    String ctx = request.getContextPath();
    // Enlace de descarga: conserva el reporte y los filtros actuales
    String csvUrl = ctx + "/ReporteServlet?csv=1&r=" + reporte
            + "&desde=" + java.net.URLEncoder.encode(fDesde == null ? "" : fDesde, "UTF-8")
            + "&hasta=" + java.net.URLEncoder.encode(fHasta == null ? "" : fHasta, "UTF-8")
            + "&tipo="  + java.net.URLEncoder.encode(fTipo  == null ? "" : fTipo,  "UTF-8");

    java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm");
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>REPORTES</title>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/estilos-reportes.css"/>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/tema-oscuro.css"/>
        <script src="${pageContext.request.contextPath}/JS/accesibilidad.js"></script>
    </head>
    <body>
        <header class="encabezado">
            <div class="logo">
                <span class="dhl"> DHL </span>
                <span class="sede"> SUPPLY CHAIN </span>
            </div>
            <div class="encabezado-usuario">
                <span>👤 ${sessionScope.nombre}</span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-salir"> Salir </a>
            </div>
        </header>

        <aside class="lateral">
            <h2 class="subtitulo"> SISTEMAS DE INVENTARIO </h2>
            <a href="${pageContext.request.contextPath}/HomeServlet" class="lista-enlaces-item">HOME</a>
            <a href="${pageContext.request.contextPath}/RegistrarServlet" class="lista-enlaces-item">REGISTRAR</a>
            <a href="${pageContext.request.contextPath}/MovimientoServlet" class="lista-enlaces-item">MOVIMIENTO</a>
            <a href="${pageContext.request.contextPath}/PAGES/ubicacion.jsp" class="lista-enlaces-item">UBICACIONES</a>
            <a href="${pageContext.request.contextPath}/ReporteServlet" class="lista-enlaces-item activo">REPORTES</a>
            <a href="${pageContext.request.contextPath}/PAGES/configuracion.jsp" class="lista-enlaces-item">CONFIGURACION</a>
        </aside>

        <main class="panel">
            <h1>Reportes</h1>
            <p class="texto-suave">CONSULTA Y DESCARGA LA INFORMACION DEL ALMACEN</p>

            <% if (mensaje != null) { %>
                <p class="aviso aviso-error"><%= Html.esc(mensaje) %></p>
            <% } %>

            <nav class="pestanas">
                <a href="<%= ctx %>/ReporteServlet?r=stock" class="pestana <%= esStock ? "activa" : "" %>">Stock actual</a>
                <a href="<%= ctx %>/ReporteServlet?r=bajo" class="pestana <%= esBajo ? "activa" : "" %>">Stock bajo</a>
                <a href="<%= ctx %>/ReporteServlet?r=movimientos" class="pestana <%= esMovs ? "activa" : "" %>">Movimientos</a>
            </nav>

            <% if (esMovs) { %>
            <section class="caja">
                <h3>Filtros</h3>
                <form action="<%= ctx %>/ReporteServlet" method="get" class="filtros">
                    <input type="hidden" name="r" value="movimientos">
                    <div class="campo">
                        <label for="desde">Desde</label>
                        <input type="date" id="desde" name="desde" value="<%= Html.esc(fDesde) %>">
                    </div>
                    <div class="campo">
                        <label for="hasta">Hasta</label>
                        <input type="date" id="hasta" name="hasta" value="<%= Html.esc(fHasta) %>">
                    </div>
                    <div class="campo">
                        <label for="tipo">Tipo</label>
                        <select id="tipo" name="tipo">
                            <option value="">Todos</option>
                            <option value="ENTRADA" <%= "ENTRADA".equals(fTipo) ? "selected" : "" %>>Entradas</option>
                            <option value="SALIDA"  <%= "SALIDA".equals(fTipo)  ? "selected" : "" %>>Salidas</option>
                        </select>
                    </div>
                    <div class="acciones-filtro">
                        <button type="submit" class="btn-guardar">FILTRAR</button>
                        <a href="<%= ctx %>/ReporteServlet?r=movimientos" class="btn-limpiar enlace-boton">LIMPIAR</a>
                    </div>
                </form>
            </section>
            <% } %>

            <section class="caja">
                <div class="caja-titulo">
                    <h3><%= esStock ? "Stock actual" : (esBajo ? "Materiales con stock bajo" : "Historial de movimientos") %></h3>
                    <a href="<%= csvUrl %>" class="btn-csv">⬇ DESCARGAR CSV</a>
                </div>

                <% if (esMovs) {
                       BigDecimal te = (BigDecimal) request.getAttribute("totalEntradas");
                       BigDecimal ts = (BigDecimal) request.getAttribute("totalSalidas"); %>
                <p class="resumen">
                    <span class="badge entrada">Entradas: +<%= te.stripTrailingZeros().toPlainString() %></span>
                    <span class="badge salida">Salidas: -<%= ts.stripTrailingZeros().toPlainString() %></span>
                    <small><%= movs.size() %> movimiento(s)</small>
                </p>
                <% if (Boolean.TRUE.equals(request.getAttribute("truncado"))) { %>
                    <p class="aviso aviso-error">Se muestran solo los 1000 mas recientes. Usa los filtros o descarga el CSV completo.</p>
                <% } %>

                <div class="tabla-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>Fecha</th><th>Tipo</th><th>Codigo de barras</th><th>Part Number</th>
                                <th>Material</th><th>Cantidad</th><th>Movimiento por</th><th>Registrado por</th><th>Motivo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% if (movs.isEmpty()) { %>
                                <tr><td colspan="9">No hay movimientos con esos filtros.</td></tr>
                            <% } else {
                                   for (Movimientobe m : movs) {
                                       boolean esEntrada = "ENTRADA".equals(m.getTipo()); %>
                                <tr>
                                    <td><%= fmt.format(m.getFecha()) %></td>
                                    <td><span class="badge <%= esEntrada ? "entrada" : "salida" %>"><%= esEntrada ? "Entrada" : "Salida" %></span></td>
                                    <td><%= Html.esc(m.getBarcode()) %></td>
                                    <td><%= Html.esc(m.getPartNumber()) %></td>
                                    <td><%= Html.esc(m.getPartName()) %></td>
                                    <td><%= esEntrada ? "+" : "-" %><%= m.getCantidad().stripTrailingZeros().toPlainString() %> <%= Html.esc(m.getSimbolo()) %></td>
                                    <td><%= Html.esc(m.getNombreUsuario() != null ? m.getNombreUsuario() : m.getUsuario()) %></td>
                                    <td><%= Html.esc(m.getNombreRegistro() != null ? m.getNombreRegistro() : m.getUsuarioRegistro()) %></td>
                                    <td><%= Html.esc(m.getMotivo()) %></td>
                                </tr>
                            <%     }
                               } %>
                        </tbody>
                    </table>
                </div>

                <% } else { %>
                <p class="resumen"><small><%= stock.size() %> material(es)</small></p>
                <div class="tabla-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>Codigo de barras</th><th>Part Number</th><th>Material</th><th>Cantidad</th>
                                <th>Minimo</th><th>Ubicacion</th><th>Registrado por</th><th>Fecha de registro</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% if (stock.isEmpty()) { %>
                                <tr><td colspan="8"><%= esBajo ? "Todo bajo control. Ningun material esta en su minimo." : "Aun no hay materiales registrados." %></td></tr>
                            <% } else {
                                   for (Materialbe m : stock) {
                                       boolean bajo = m.getMinimo() != null && m.getCantidad().compareTo(m.getMinimo()) <= 0; %>
                                <tr class="<%= bajo ? "fila-alerta" : "" %>">
                                    <td><%= Html.esc(m.getBarcode()) %></td>
                                    <td><%= Html.esc(m.getPartNumber()) %></td>
                                    <td><%= Html.esc(m.getPartName()) %></td>
                                    <td><%= m.getCantidad().stripTrailingZeros().toPlainString() %> <%= Html.esc(m.getSimbolo()) %></td>
                                    <td><%= m.getMinimo() == null ? "-" : m.getMinimo().stripTrailingZeros().toPlainString() %></td>
                                    <td><%= Html.esc(m.getUbi()) %></td>
                                    <td><%= Html.esc(m.getNombreRegistro() != null ? m.getNombreRegistro() : m.getUsuarioRegistro()) %></td>
                                    <td><%= fmt.format(m.getFechaRegistro()) %></td>
                                </tr>
                            <%     }
                               } %>
                        </tbody>
                    </table>
                </div>
                <% } %>
            </section>
        </main>

        <script src="${pageContext.request.contextPath}/JS/logout.js"></script>
    </body>
</html>
