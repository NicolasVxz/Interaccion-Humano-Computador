<%-- 
    Document   : configuracion
    Created on : 28 oct. 2026, 11:46:59
    Author     : josep
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if(session.getAttribute("usuario") == null){
        response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
        return;
    }
    java.util.List<Object[]> alertas = (java.util.List<Object[]>) request.getAttribute("alertas");
    java.util.List<Object[]> movimientos = (java.util.List<Object[]>) request.getAttribute("movimientos");
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>CONFIGURACION</title>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/estilos-configuracion.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-B/GM4XqrwHnWXNOWMbloTmrYXZg10cakYGmpfsR/bbzQ6JAJI4ihuyADKLnBgrCe" crossorigin="anonymous">
        <script type="module" src="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-1a/pXj49ZQ1aHEmrJ+gMw1otqoVsYwlEnlD8mIfY2TV03r20Y0CN7uqx1tQogjPL" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/tema-oscuro.css"/>
        <script src="${pageContext.request.contextPath}/JS/accesibilidad.js"></script>
    </head>
    <body>
        <header class="encabezado">
            <div class="logo">
                <span class="dhl"> DHL </span>
                <span class="sede"> SUPPLY CHAIN </span>          
            </div>
            <div class="encabezado-usuario">
                <span>👤 ${sessionScope.nombre}</span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-salir"> Salir </a>
            </div>
        </header>
            <aside class="lateral">
                <div class="lista-enlaces"></div>
                <h2 class="subtitulo"> SISTEMAS DE INVENTARIO </h2>
                <a href="${pageContext.request.contextPath}/HomeServlet" class="lista-enlaces-item ">HOME</a>
                <a href="${pageContext.request.contextPath}/RegistrarServlet" class="lista-enlaces-item">REGISTRAR</a>
                <a href="${pageContext.request.contextPath}/MovimientoServlet" class="lista-enlaces-item">MOVIMIENTO</a>
                <a href="${pageContext.request.contextPath}/PAGES/ubicacion.jsp" class="lista-enlaces-item">UBICACIONES</a>
                <a href="${pageContext.request.contextPath}/ReporteServlet" class="lista-enlaces-item">REPORTES</a>
                <a href="${pageContext.request.contextPath}/PAGES/configuracion.jsp" class="lista-enlaces-item activo">CONFIGURACION</a>            
            </aside>
            <main class="panel">
                <h1>Configuración</h1>
                <p class="texto-suave">PERSONALIZA CÓMO SE VE Y SE ESCUCHA EL SISTEMA EN ESTE NAVEGADOR</p>

                <section class="caja">
                    <h3>Apariencia</h3>
                    <p class="texto-suave">Elige el color de la pantalla. El tema oscuro usa fondo negro y letras blancas en todas las páginas.</p>
                    <div class="opciones-tema">
                        <label class="opcion-tema">
                            <input type="radio" name="tema" value="claro" id="temaClaro">
                            <span class="muestra muestra-claro">Aa</span>
                            <span>Claro</span>
                        </label>
                        <label class="opcion-tema">
                            <input type="radio" name="tema" value="oscuro" id="temaOscuro">
                            <span class="muestra muestra-oscuro">Aa</span>
                            <span>Oscuro (letras blancas)</span>
                        </label>
                    </div>
                </section>

                <section class="caja">
                    <h3>Audio</h3>
                    <p class="texto-suave">Cuando está activado, cada párrafo muestra un botón 🔊 y también puedes hacer clic sobre el texto para escucharlo.</p>
                    <label class="interruptor">
                        <input type="checkbox" id="audioActivo">
                        <span>Leer los párrafos en voz alta</span>
                    </label>
                    <div class="fila-velocidad">
                        <label for="audioVelocidad">Velocidad de lectura: <b id="velocidadTexto">1.0x</b></label>
                        <input type="range" id="audioVelocidad" min="0.6" max="1.6" step="0.1" value="1">
                    </div>
                    <div class="acciones-config">
                        <button type="button" class="btn-config" id="btnProbar">🔊 Probar voz</button>
                        <button type="button" class="btn-config" id="btnLeerTodo">▶ Leer toda la página</button>
                        <button type="button" class="btn-config" id="btnDetener">■ Detener</button>
                    </div>
                    <p class="aviso-error" id="avisoVoz"></p>
                </section>

                <section class="caja">
                    <h3>Restablecer</h3>
                    <p class="texto-suave">Vuelve al tema claro y desactiva el audio.</p>
                    <button type="button" class="btn-config btn-peligro" id="btnRestablecer">Restablecer opciones</button>
                </section>
            </main>
            <script src="${pageContext.request.contextPath}/JS/configuracion.js"></script>
            <script src="${pageContext.request.contextPath}/JS/logout.js"></script>
    </body>
</html>
