<%-- 
    Document   : registrar
    Created on : 28 oct. 2026, 11:45:13
    Author     : josep
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List, com.maven.dhlinvetario.be.Movimientobe, com.maven.dhlinvetario.util.Html"%>
<%
    // 1. Sin sesion -> al login
    if (session.getAttribute("usuario") == null) {
        response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
        return;
    }
    // 2. Si abrieron el JSP directo (sin pasar por el servlet) los mandamos al servlet
    if (request.getAttribute("movimientos") == null) {
        response.sendRedirect(request.getContextPath() + "/MovimientoServlet");
        return;
    }

    List<Movimientobe> movimientos = (List<Movimientobe>) request.getAttribute("movimientos");

    String mensaje = (String) request.getAttribute("mensaje");
    boolean esOk = Boolean.TRUE.equals(request.getAttribute("esOk"));

    // Si hubo error, se vuelve a poner lo que el usuario escribio
    String vBarcode  = request.getParameter("Barcode");
    String vTipo     = request.getParameter("Tipo");
    String vCantidad = request.getParameter("Cantidad");
    String vMotivo   = request.getParameter("Motivo");
    if (esOk) { vBarcode = vTipo = vCantidad = vMotivo = null; }

    java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm");
%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>MOVIMIENTOS</title>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/estilos-movimientos.css"/>
        <link rel="stylesheet" href="${pageContext.request.contextPath}/ESTILOS/tema-oscuro.css"/>
        <script src="${pageContext.request.contextPath}/JS/accesibilidad.js"></script>
    </head>
    <body>
        <header class="encabezado">
            <div class="logo">
                <span class="dhl"> DHL </span>
                <span class="sede"> SUPPLY CHAIN </span>
            </div>
            <div class="encabezado-usuario">
                <span>👤 ${sessionScope.nombre}</span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-salir"> Salir </a>
            </div>
        </header>

        <aside class="lateral">
            <h2 class="subtitulo"> SISTEMAS DE INVENTARIO </h2>
            <a href="${pageContext.request.contextPath}/HomeServlet" class="lista-enlaces-item">HOME</a>
            <a href="${pageContext.request.contextPath}/RegistrarServlet" class="lista-enlaces-item">REGISTRAR</a>
            <a href="${pageContext.request.contextPath}/MovimientoServlet" class="lista-enlaces-item activo">MOVIMIENTO</a>
            <a href="${pageContext.request.contextPath}/PAGES/ubicacion.jsp" class="lista-enlaces-item">UBICACIONES</a>
            <a href="${pageContext.request.contextPath}/ReporteServlet" class="lista-enlaces-item">REPORTES</a>
            <a href="${pageContext.request.contextPath}/PAGES/configuracion.jsp" class="lista-enlaces-item">CONFIGURACION</a>
        </aside>

        <main class="panel">
            <h1>Movimientos</h1>
            <p class="texto-suave">REGISTRA ENTRADAS Y SALIDAS DE MATERIAL</p>

            <% if (mensaje != null) { %>
                <p class="aviso <%= esOk ? "aviso-ok" : "aviso-error" %>"><%= Html.esc(mensaje) %></p>
            <% } %>

            <section class="caja">
                <h3>Nuevo movimiento</h3>
                <form action="${pageContext.request.contextPath}/MovimientoServlet" method="post" class="formulario" id="formMovimiento">

                    <div class="campo campo-ancho">
                        <label for="Barcode">Codigo de barras</label>
                        <input type="text" id="Barcode" name="Barcode" maxlength="50"
                               value="<%= Html.esc(vBarcode) %>"
                               placeholder="Escanea o escribe el codigo" autocomplete="off" required autofocus>
                    </div>

                    <div class="campo">
                        <label for="Tipo">Tipo de movimiento</label>
                        <select id="Tipo" name="Tipo" required>
                            <option value="ENTRADA" <%= "ENTRADA".equals(vTipo) ? "selected" : "" %>>ENTRADA (suma stock)</option>
                            <option value="SALIDA"  <%= "SALIDA".equals(vTipo)  ? "selected" : "" %>>SALIDA (resta stock)</option>
                        </select>
                    </div>

                    <div class="campo">
                        <label for="Cantidad">Cantidad</label>
                        <input type="number" id="Cantidad" name="Cantidad" step="0.01" min="0.01" max="99999999.99"
                               value="<%= Html.esc(vCantidad) %>"
                               placeholder="0.00" required>
                    </div>

                    <div class="campo campo-ancho">
                        <label for="Motivo">Motivo</label>
                        <input type="text" id="Motivo" name="Motivo" maxlength="200"
                               value="<%= Html.esc(vMotivo) %>"
                               placeholder="Ej: Reposicion de proveedor / Pedido de produccion" autocomplete="off" required>
                    </div>

                    <div class="acciones">
                        <button type="submit" class="btn-guardar">REGISTRAR MOVIMIENTO</button>
                        <button type="reset" class="btn-limpiar">LIMPIAR</button>
                    </div>
                </form>
            </section>

            <section class="caja">
                <h3>Ultimos movimientos</h3>
                <div class="tabla-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Tipo</th>
                                <th>Codigo de barras</th>
                                <th>Material</th>
                                <th>Cantidad</th>
                                <th>Movimiento por</th>
                                <th>Registrado por</th>
                                <th>Motivo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% if (movimientos.isEmpty()) { %>
                                <tr><td colspan="8">Aun no hay movimientos.</td></tr>
                            <% } else {
                                   for (Movimientobe m : movimientos) {
                                       boolean esEntrada = "ENTRADA".equals(m.getTipo()); %>
                                <tr>
                                    <td><%= fmt.format(m.getFecha()) %></td>
                                    <td><span class="badge <%= esEntrada ? "entrada" : "salida" %>"><%= esEntrada ? "Entrada" : "Salida" %></span></td>
                                    <td><%= Html.esc(m.getBarcode()) %></td>
                                    <td><%= Html.esc(m.getPartName()) %></td>
                                    <td><%= esEntrada ? "+" : "-" %><%= m.getCantidad().stripTrailingZeros().toPlainString() %> <%= Html.esc(m.getSimbolo()) %></td>
                                    <td><%= Html.esc(m.getNombreUsuario() != null ? m.getNombreUsuario() : m.getUsuario()) %></td>
                                    <td><%= Html.esc(m.getNombreRegistro() != null ? m.getNombreRegistro() : m.getUsuarioRegistro()) %></td>
                                    <td><%= Html.esc(m.getMotivo()) %></td>
                                </tr>
                            <%     }
                               } %>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <script src="${pageContext.request.contextPath}/JS/logout.js"></script>
        <script src="${pageContext.request.contextPath}/JS/movimientos.js"></script>
    </body>
</html>
