/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */
document.addEventListener("DOMContentLoaded", function () {
    var A = window.DHLAccesibilidad;
    if (!A) return;

    var temaClaro = document.getElementById("temaClaro");
    var temaOscuro = document.getElementById("temaOscuro");
    var audio = document.getElementById("audioActivo");
    var vel = document.getElementById("audioVelocidad");
    var velTxt = document.getElementById("velocidadTexto");
    var aviso = document.getElementById("avisoVoz");

    function pintarEstado() {
        (A.getTema() === "oscuro" ? temaOscuro : temaClaro).checked = true;
        audio.checked = A.getAudio();
        vel.value = A.getVelocidad();
        velTxt.textContent = Number(vel.value).toFixed(1) + "x";
    }
    pintarEstado();

    if (!A.soportaVoz) {
        aviso.textContent = "Tu navegador no soporta lectura en voz alta. Prueba con Chrome o Edge.";
        audio.disabled = true;
    }

    [temaClaro, temaOscuro].forEach(function (r) {
        r.addEventListener("change", function () { A.setTema(r.value); });
    });
    audio.addEventListener("change", function () { A.setAudio(audio.checked); });
    vel.addEventListener("input", function () {
        A.setVelocidad(vel.value);
        velTxt.textContent = Number(vel.value).toFixed(1) + "x";
    });
    document.getElementById("btnProbar").addEventListener("click", A.probar);
    document.getElementById("btnLeerTodo").addEventListener("click", A.leerTodo);
    document.getElementById("btnDetener").addEventListener("click", A.detener);
    document.getElementById("btnRestablecer").addEventListener("click", function () {
        A.restablecer();
        pintarEstado();
    });
});

