/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

document.addEventListener("DOMContentLoaded", function () {

    const barcode = document.getElementById("Barcode");
    const cantidad = document.getElementById("Cantidad");

    // El lector de codigo de barras termina con Enter: en vez de enviar el formulario, pasa a Cantidad
    if (barcode && cantidad) {
        barcode.addEventListener("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                cantidad.focus();
            }
        });
    }

    const form = document.getElementById("formMovimiento");
    if (form && barcode) {
        form.addEventListener("reset", function () {
            setTimeout(function () { barcode.focus(); }, 0);
        });
    }

    // Quita ?ok=1&barcode=... de la barra de direcciones para que F5 no repita nada
    if (window.history.replaceState && window.location.search) {
        window.history.replaceState(null, "", window.location.pathname);
    }
});

