/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */
(function () {
    "use strict";

    var CLAVES = { tema: "dhl_tema", audio: "dhl_audio", velocidad: "dhl_audio_velocidad" };

    function leer(clave, porDefecto) {
        try {
            var v = localStorage.getItem(clave);
            return v === null ? porDefecto : v;
        } catch (e) { return porDefecto; }
    }
    function guardar(clave, valor) {
        try { localStorage.setItem(clave, valor); } catch (e) { /* modo privado: se ignora */ }
    }

    /* ---------- TEMA ---------- */
    function aplicarTema(tema) {
        var html = document.documentElement;
        html.classList.toggle("tema-oscuro", tema === "oscuro");
        html.setAttribute("data-bs-theme", tema === "oscuro" ? "dark" : "light");
    }
    aplicarTema(leer(CLAVES.tema, "claro"));   // inmediato, antes de pintar (evita el parpadeo blanco)

    /* ---------- AUDIO (Web Speech API) ---------- */
    var soportaVoz = "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;
    var SELECTOR_LEIBLE = "p, h1, h2, h3, li, .guiatext, .accordion-body";
    var SELECTOR_EXCLUIDO = "header, aside, .encabezado, .lateral, .no-leer";
    var leyendoEl = null;

    function elegirVoz() {
        var voces = window.speechSynthesis.getVoices();
        var prefer = ["es-PE", "es-MX", "es-US", "es-ES"];
        for (var i = 0; i < prefer.length; i++) {
            for (var j = 0; j < voces.length; j++) {
                if (voces[j].lang && voces[j].lang.replace("_", "-") === prefer[i]) return voces[j];
            }
        }
        for (var k = 0; k < voces.length; k++) {
            if (voces[k].lang && voces[k].lang.toLowerCase().indexOf("es") === 0) return voces[k];
        }
        return null;
    }

    function textoDe(el) {
        var copia = el.cloneNode(true);
        var botones = copia.querySelectorAll(".btn-voz");
        for (var i = 0; i < botones.length; i++) botones[i].remove();
        return (copia.textContent || "").replace(/\s+/g, " ").trim();
    }

    function detener() {
        if (!soportaVoz) return;
        window.speechSynthesis.cancel();
        if (leyendoEl) { leyendoEl.classList.remove("leyendo"); leyendoEl = null; }
    }

    function hablar(texto, el, alTerminar) {
        if (!soportaVoz || !texto) return;
        window.speechSynthesis.cancel();
        if (leyendoEl) leyendoEl.classList.remove("leyendo");
        var u = new SpeechSynthesisUtterance(texto);
        var voz = elegirVoz();
        if (voz) { u.voice = voz; u.lang = voz.lang; } else { u.lang = "es-PE"; }
        u.rate = parseFloat(leer(CLAVES.velocidad, "1")) || 1;
        leyendoEl = el || null;
        if (leyendoEl) leyendoEl.classList.add("leyendo");
        function fin() {
            if (el) el.classList.remove("leyendo");
            if (leyendoEl === el) leyendoEl = null;
            if (alTerminar) alTerminar();
        }
        u.onend = fin;
        u.onerror = fin;
        window.speechSynthesis.speak(u);
    }

    function bloquesLeibles() {
        var lista = [];
        var todos = document.querySelectorAll(SELECTOR_LEIBLE);
        for (var i = 0; i < todos.length; i++) {
            var el = todos[i];
            if (el.closest(SELECTOR_EXCLUIDO)) continue;
            if (!textoDe(el)) continue;
            // si es un contenedor que ya contiene otros bloques, se leen esos por separado
            if (el.matches(".accordion-body") && el.querySelector("p, li")) continue;
            lista.push(el);
        }
        return lista;
    }

    function leerTodo() {
        var cola = bloquesLeibles();
        var i = 0;
        (function siguiente() {
            if (i >= cola.length) return;
            var el = cola[i++];
            hablar(textoDe(el), el, siguiente);
        })();
    }

    function activarAudio() {
        document.documentElement.classList.add("audio-activo");
        var bloques = bloquesLeibles();
        for (var i = 0; i < bloques.length; i++) {
            var el = bloques[i];
            el.classList.add("leible");
            // boton 🔊 solo en los parrafos <p>
            if (el.tagName === "P" && !el.querySelector(".btn-voz")) {
                var b = document.createElement("button");
                b.type = "button";
                b.className = "btn-voz";
                b.title = "Escuchar este párrafo";
                b.setAttribute("aria-label", "Escuchar este párrafo");
                b.textContent = "🔊";
                el.appendChild(b);
            }
        }
    }

    function desactivarAudio() {
        detener();
        document.documentElement.classList.remove("audio-activo");
        var marcados = document.querySelectorAll(".leible");
        for (var i = 0; i < marcados.length; i++) marcados[i].classList.remove("leible");
        var botones = document.querySelectorAll(".btn-voz");
        for (var j = 0; j < botones.length; j++) botones[j].remove();
    }

    function onClickDocumento(e) {
        if (!document.documentElement.classList.contains("audio-activo")) return;
        var t = e.target;
        if (t.closest("a, input, select, textarea, label, .no-leer") ) return;
        if (t.closest("button") && !t.closest(".btn-voz")) return;
        if (window.getSelection && String(window.getSelection()).length > 0) return;
        var el = t.closest(".leible");
        if (!el) return;
        // el bloque mas interno que sea leible
        hablar(textoDe(el), el);
    }

    /* ---------- API publica para la pantalla de Configuracion ---------- */
    window.DHLAccesibilidad = {
        soportaVoz: soportaVoz,
        getTema: function () { return leer(CLAVES.tema, "claro"); },
        setTema: function (t) { guardar(CLAVES.tema, t); aplicarTema(t); },
        getAudio: function () { return leer(CLAVES.audio, "off") === "on"; },
        setAudio: function (on) {
            guardar(CLAVES.audio, on ? "on" : "off");
            if (on) activarAudio(); else desactivarAudio();
        },
        getVelocidad: function () { return parseFloat(leer(CLAVES.velocidad, "1")) || 1; },
        setVelocidad: function (v) { guardar(CLAVES.velocidad, String(v)); },
        probar: function () { hablar("Así sonará la lectura de los párrafos en el sistema de inventario.", null); },
        leerTodo: leerTodo,
        detener: detener,
        restablecer: function () {
            guardar(CLAVES.tema, "claro"); guardar(CLAVES.audio, "off"); guardar(CLAVES.velocidad, "1");
            aplicarTema("claro"); desactivarAudio();
        }
    };

    document.addEventListener("DOMContentLoaded", function () {
        if (soportaVoz) {
            window.speechSynthesis.getVoices();   // fuerza la carga de voces en Chrome
            document.addEventListener("click", onClickDocumento);
            window.addEventListener("beforeunload", function () { window.speechSynthesis.cancel(); });
            if (leer(CLAVES.audio, "off") === "on") activarAudio();
        }
    });
})();


