/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */
 document.addEventListener("DOMContentLoaded", function(){
    const fechaEl = document.getElementById("FECHA");
        if (fechaEl) {
            fechaEl.textContent = new Date().toLocaleDateString("es-PE", {
                day: "2-digit", month: "short", year: "numeric"
        });
    }
});
    