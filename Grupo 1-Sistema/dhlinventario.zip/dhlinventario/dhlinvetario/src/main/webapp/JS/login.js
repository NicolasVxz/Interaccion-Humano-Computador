document.addEventListener("DOMContentLoaded", function () {

    // Mostrar u ocultar contraseña
    const verClave = document.getElementById("verClave");
    const clave = document.querySelector('input[name="Clave"]');

    if (verClave && clave) {
        verClave.addEventListener("change", function () {
            if (this.checked) {
                clave.type = "text";
            } else {
                clave.type = "password";
            }
        });
    }

    // Validar que los campos no estén vacíos
    const formulario = document.querySelector("form");

    if (formulario) {
        formulario.addEventListener("submit", function (event) {

            const usuario = document.querySelector(
                'input[name="Usuario"]'
            ).value.trim();

            const contrasena = document.querySelector(
                'input[name="Clave"]'
            ).value;

            if (usuario === "" || contrasena.trim() === "") {
                event.preventDefault();
                alert("Ingrese su usuario y contraseña.");
            }
        });
    }

});


