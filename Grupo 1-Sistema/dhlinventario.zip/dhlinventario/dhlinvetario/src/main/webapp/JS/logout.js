/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */
 document.addEventListener("DOMContentLoaded", function(){
const salir = document.querySelector(".btn-salir");
    if (salir) {
        salir.addEventListener("click", function (e) {
            if (!confirm("¿DESEAS CERRAR SESION?")) e.preventDefault();
        });
        }
    }
);
