/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


document.addEventListener("DOMContentLoaded", function () {

    const barcode = document                                                                                                                                                                                                                                                            .getElementById("Barcode");
    const partNumber = document.getElementById("PartNumber");

      if (barcode && partNumber) {
        barcode.addEventListener("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                partNumber.focus();
            }
        });
    }

     const form = document.getElementById("formRegistrar");
    if (form && barcode) {
        form.addEventListener("reset", function () {
            setTimeout(function () { barcode.focus(); }, 0);
        });
    }

     if (window.history.replaceState && window.location.search) {
        window.history.replaceState(null, "", window.location.pathname);
    }
});