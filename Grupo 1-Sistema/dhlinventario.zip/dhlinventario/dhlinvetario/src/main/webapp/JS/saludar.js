 document.addEventListener("DOMContentLoaded", function(){
     const hora = new Date().getHours();
     let saludo = "BUENAS NOCHES";
     if(hora<12) saludo = "BUENOS DIAS";
     else if (hora<19) saludo = "BUENAS TARDES";
     document.getElementById("saludo").textContent = saludo;      
    }
);
