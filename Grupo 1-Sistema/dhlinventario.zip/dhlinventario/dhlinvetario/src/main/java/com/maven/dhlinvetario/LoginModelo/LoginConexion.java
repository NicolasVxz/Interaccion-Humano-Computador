/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.LoginModelo;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
public class LoginConexion {
 
  
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=DHL_INVENTARIO_BD;encrypt=true;trustServerCertificate=true;";
    private static final String USUARIO = "sabd";
    private static final String CLAVE = "1919";
 
    public static Connection getConnection() throws SQLException {
        try {
            
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("No se encontro el driver de SQL Server");
        }
        
        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }
}