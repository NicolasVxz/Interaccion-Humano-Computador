/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinventario.prueba;

import com.maven.dhlinvetario.LoginModelo.LoginConexion;
import com.maven.dhlinvetario.be.Personalbe;
import com.maven.dhlinvetario.dao.Personaldao;
import java.sql.Connection;
 
public class PruebaConexion {
 
    public static void main(String[] args) {
 
        
        try {
            Connection cn = LoginConexion.getConnection();
            System.out.println("PRUEBA 1 OK: conectado a la base " + cn.getCatalog());
            cn.close();
        } catch (Exception e) {
            System.out.println("PRUEBA 1 ERROR: no conecta con la base de datos");
            System.out.println("Motivo: " + e.getMessage());
            return; // si no conecta, no tiene sentido hacer la prueba 2
        }
 
        
        try {
            Personaldao dao = new Personaldao();
            Personalbe p = dao.validar("4863355", "1919");
 
            if (p != null) {
                System.out.println("PRUEBA 2 OK: usuario encontrado -> "
                        + p.getFirstNombre() + " " + p.getFirstApellido());
            } else {
                System.out.println("PRUEBA 2: conecta bien, pero ese usuario/clave no existe en la tabla Personal");
            }
        } catch (Exception e) {
            System.out.println("PRUEBA 2 ERROR: " + e.getMessage());
        }
    }
}