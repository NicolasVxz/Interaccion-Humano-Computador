/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.util;

/**
 *
 * @author josep
 */
public class Html {
    public static String esc(Object o){
        if( o==null )return "";
        return o.toString()
                .replace("&","&amp;")
                .replace("<","&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'","&#39;");
    }
}
