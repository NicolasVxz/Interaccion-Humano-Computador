package com.maven.dhlinvetario.br;

import com.maven.dhlinvetario.be.Materialbe;
import com.maven.dhlinvetario.be.Movimientobe;
import com.maven.dhlinvetario.dao.Materialdao;
import com.maven.dhlinvetario.dao.Movimientodao;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class Movimientobr {

    private final Movimientodao dao = new Movimientodao();
    private final Materialdao materialDao = new Materialdao();
    private static final BigDecimal MAXIMO = new BigDecimal("99999999.99");

    
    public String registrar(String barcode, String tipo, String cantidad,
                            String motivo, String usuario) throws SQLException {

        barcode  = limpiar(barcode);
        tipo     = limpiar(tipo).toUpperCase();
        cantidad = limpiar(cantidad);
        motivo   = limpiar(motivo);
        usuario  = limpiar(usuario);

        if (usuario.isEmpty()) {
            return "sesion";
        }
        if (barcode.isEmpty() || tipo.isEmpty() || cantidad.isEmpty() || motivo.isEmpty()) {
            return "vacio";
        }
        if (!tipo.equals("ENTRADA") && !tipo.equals("SALIDA")) {
            return "tipo";
        }
        if (barcode.length() > 50 || motivo.length() > 200) {
            return "largo";
        }

        BigDecimal cant;
        try {
            cant = new BigDecimal(cantidad.replace(',', '.'));
        } catch (NumberFormatException e) {
            return "cantidad";
        }
        cant = cant.setScale(2, RoundingMode.HALF_UP);
        if (cant.signum() <= 0 || cant.compareTo(MAXIMO) > 0) {
            return "cantidad";
        }

        return dao.registrar(barcode, tipo, cant, usuario, motivo);
    }

    public List<Movimientobe> recientes() throws SQLException {
        return dao.listar(null, null, null, null, 15);
    }

    public List<Movimientobe> listar(String desde, String hasta, String tipo, int limite) throws SQLException {
        String t = limpiar(tipo).toUpperCase();
        if (!t.equals("ENTRADA") && !t.equals("SALIDA")) {
            t = null;
        }
        return dao.listar(aFecha(desde), aFecha(hasta), t, null, limite);
    }

    public Materialbe buscarMaterial(String barcode) throws SQLException {
        return materialDao.buscarPorBarcode(limpiar(barcode));
    }

    private Date aFecha(String s) {
        s = limpiar(s);
        if (s.isEmpty()) {
            return null;
        }
        try {
            return Date.valueOf(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private String limpiar(String s) {
        return s == null ? "" : s.trim();
    }
}
