/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.be;

public class Personalbe {
 
    private String usuario;
    private String firstNombre;
    private String secondNombre;
    private String firstApellido;
    private String secondApellido;
 
    public String getUsuario() {
        return usuario;
    }
 
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
 
    public String getFirstNombre() {
        return firstNombre;
    }
 
    public void setFirstNombre(String firstNombre) {
        this.firstNombre = firstNombre;
    }
 
    public String getSecondNombre() {
        return secondNombre;
    }
 
    public void setSecondNombre(String secondNombre) {
        this.secondNombre = secondNombre;
    }
 
    public String getFirstApellido() {
        return firstApellido;
    }
 
    public void setFirstApellido(String firstApellido) {
        this.firstApellido = firstApellido;
    }
 
    public String getSecondApellido() {
        return secondApellido;
    }
 
    public void setSecondApellido(String secondApellido) {
        this.secondApellido = secondApellido;
    }
}