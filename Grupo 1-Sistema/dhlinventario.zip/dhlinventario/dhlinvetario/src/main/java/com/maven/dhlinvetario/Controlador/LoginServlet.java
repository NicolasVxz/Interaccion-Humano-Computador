   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.maven.dhlinvetario.Controlador;

import com.maven.dhlinvetario.be.Personalbe;
import com.maven.dhlinvetario.br.Personalbr;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
 
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
        String ctx = request.getContextPath();
 
        String usuario = request.getParameter("Usuario");
        String clave = request.getParameter("Clave");
 
        if (usuario == null || clave == null || usuario.equals("") || clave.equals("")) {
            response.sendRedirect(ctx + "/PAGES/login.jsp?error=1");
            return;
        }
 
        try {
            Personalbr br = new Personalbr();
            Personalbe p = br.validar(usuario, clave);
 
            if (p != null) {
                HttpSession sesion = request.getSession();
                sesion.setAttribute("usuario", p.getUsuario());
                sesion.setAttribute("nombre", p.getFirstNombre() + " " + p.getFirstApellido());
                response.sendRedirect(ctx + "/HomeServlet");
            } else {
                response.sendRedirect(ctx + "/PAGES/login.jsp?error=1");
            }
 
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(ctx + "/PAGES/login.jsp?error=2");
        }
    }
 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
    }
}
 