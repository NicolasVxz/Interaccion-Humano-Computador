/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.br;

 
import com.maven.dhlinvetario.be.Personalbe;
import com.maven.dhlinvetario.dao.Personaldao;
import java.sql.SQLException;
 
public class Personalbr {
 
    public Personalbe validar(String usuario, String clave) throws SQLException {
        Personaldao dao = new Personaldao();
        return dao.validar(usuario, clave);
    }
}
 