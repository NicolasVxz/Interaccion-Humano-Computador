/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.br;

import com.maven.dhlinvetario.be.Materialbe;
import com.maven.dhlinvetario.dao.Materialdao;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.List;

public class Materialbr {

    private final Materialdao dao = new Materialdao();
    private static final BigDecimal MAXIMO = new BigDecimal("99999999.99");

    // "usuario" es el codigo de quien esta logueado: se guarda junto al material
    public String registrar(String barcode, String partNumber, String partName,
                            String cantidad, String simbolo, String ubi,
                            String minimo, String usuario) throws SQLException {

        barcode    = limpiar(barcode);
        partNumber = limpiar(partNumber);
        partName   = limpiar(partName);
        cantidad   = limpiar(cantidad);
        simbolo    = limpiar(simbolo);
        ubi        = limpiar(ubi);
        minimo     = limpiar(minimo);
        usuario    = limpiar(usuario);

        if (usuario.isEmpty()) {
            return "sesion";
        }

        if (barcode.isEmpty() || partNumber.isEmpty() || partName.isEmpty()
                || cantidad.isEmpty() || simbolo.isEmpty() || ubi.isEmpty()) {
            return "vacio";
        }

        if (barcode.length() > 50 || partNumber.length() > 50 || partName.length() > 120
                || simbolo.length() > 5 || ubi.length() > 25) {
            return "largo";
        }

        BigDecimal cant;
        try {
            cant = new BigDecimal(cantidad.replace(',', '.'));
        } catch (NumberFormatException e) {
            return "cantidad";
        }
        cant = cant.setScale(2, RoundingMode.HALF_UP);
        if (cant.signum() < 0 || cant.compareTo(MAXIMO) > 0) {
            return "cantidad";
        }

        // Stock minimo: es opcional. Si lo escriben tiene que ser un numero >= 0
        BigDecimal min = null;
        if (!minimo.isEmpty()) {
            try {
                min = new BigDecimal(minimo.replace(',', '.')).setScale(2, RoundingMode.HALF_UP);
            } catch (NumberFormatException e) {
                return "minimo";
            }
            if (min.signum() < 0 || min.compareTo(MAXIMO) > 0) {
                return "minimo";
            }
        }

        String medidaBD = dao.buscarMedida(simbolo);
        if (medidaBD == null) {
            return "medida";
        }

        String ubiBD = dao.buscarUbicacion(ubi);
        if (ubiBD == null) {
            return "ubicacion";
        }

        if (dao.existeBarcode(barcode)) {
            return "dup";
        }

        Materialbe m = new Materialbe();
        m.setBarcode(barcode);
        m.setPartNumber(partNumber);
        m.setPartName(partName);
        m.setCantidad(cant);
        m.setSimbolo(medidaBD);
        m.setUbi(ubiBD);
        m.setMinimo(min);
        m.setUsuarioRegistro(usuario);   
        dao.insertar(m);
        return null;
    }

    public List<Materialbe> recientes() throws SQLException {
        return dao.listarRecientes(10);
    }

    // Stock actual para el reporte (soloBajoMinimo = true -> solo los que llegaron al minimo)
    public List<Materialbe> stock(boolean soloBajoMinimo) throws SQLException {
        return dao.listarStock(soloBajoMinimo);
    }

    private String limpiar(String s) {
        return s == null ? "" : s.trim();
    }
}