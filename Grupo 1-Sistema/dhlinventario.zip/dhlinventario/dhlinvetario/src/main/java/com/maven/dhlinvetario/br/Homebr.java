/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.br;

import com.maven.dhlinvetario.dao.Homedao;
import java.sql.SQLException;
import java.util.List;

public class Homebr {

    private final Homedao dao = new Homedao();

    public int contarPartNumbers() throws SQLException { return dao.contarPartNumbers(); }
    public int totalUnidades()     throws SQLException { return dao.totalUnidades(); }
    public int ingresosHoy()       throws SQLException { return dao.ingresosHoy(); }
    public int salidasHoy()        throws SQLException { return dao.salidasHoy(); }
    public List<Object[]> alertas()     throws SQLException { return dao.alertasStock(); }
    public List<Object[]> movimientos() throws SQLException { return dao.ultimosMovimientos(); }
}
