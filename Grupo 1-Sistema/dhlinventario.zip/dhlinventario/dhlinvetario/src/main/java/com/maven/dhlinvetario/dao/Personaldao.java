/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.dao;

import com.maven.dhlinvetario.LoginModelo.LoginConexion;
import com.maven.dhlinvetario.be.Personalbe;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class Personaldao {
 
    public Personalbe validar(String usuario, String clave) throws SQLException {
 
        Personalbe p = null;
 
        String sql = "SELECT Usuario, First_Nombre, Second_Nombre, First_Apellido, Second_Apellido "
                + "FROM Personal WHERE Usuario = ? AND Clave = ?";
 
        Connection cn = LoginConexion.getConnection();
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, usuario);
        ps.setString(2, clave);
 
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            p = new Personalbe();
            p.setUsuario(rs.getString("Usuario"));
            p.setFirstNombre(rs.getString("First_Nombre"));
            p.setSecondNombre(rs.getString("Second_Nombre"));
            p.setFirstApellido(rs.getString("First_Apellido"));
            p.setSecondApellido(rs.getString("Second_Apellido"));
        }
 
        rs.close();
        ps.close();
        cn.close();
 
        return p;
    }
}