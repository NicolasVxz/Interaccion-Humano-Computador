package com.maven.dhlinvetario.dao;

import com.maven.dhlinvetario.LoginModelo.LoginConexion;
import com.maven.dhlinvetario.be.Materialbe;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Materialdao {

    // Nombre completo de quien registro: "Max Ruso" (igual que el nombre que se muestra en la cabecera)
    private static final String NOMBRE_PERSONAL = "(p.First_Nombre + ' ' + p.First_Apellido)";

    public String buscarMedida(String simbolo) throws SQLException {
        return buscarTexto("SELECT Simbolo FROM Medida WHERE Simbolo = ?", simbolo);
    }

    public String buscarUbicacion(String ubi) throws SQLException {
        return buscarTexto("SELECT Ubi FROM Ubicacion WHERE Ubi = ? AND Estado = 'ACTIVO'", ubi);
    }

    public boolean existeBarcode(String barcode) throws SQLException {
        return buscarTexto("SELECT Barcode FROM Material WHERE Barcode = ?", barcode) != null;
    }

    // Guarda el material + el usuario que lo registro + (opcional) su stock minimo
    // + un movimiento ENTRADA "Registro inicial". Todo en una transaccion: o se guarda todo o nada.
    public void insertar(Materialbe m) throws SQLException {
        String sqlMaterial = "INSERT INTO Material (Barcode, Part_Number, Part_Name, Cantidad, Simbolo, Ubi, Usuario_Registro) "
                           + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        String sqlMinimo = "INSERT INTO Stock_Minimo (Barcode, Minimo) VALUES (?, ?)";
        String sqlMov = "INSERT INTO Movimiento (Barcode, Tipo, Cantidad, Usuario, Motivo) "
                      + "VALUES (?, 'ENTRADA', ?, ?, 'Registro inicial')";

        try (Connection cn = LoginConexion.getConnection()) {
            cn.setAutoCommit(false);
            try {
                try (PreparedStatement ps = cn.prepareStatement(sqlMaterial)) {
                    ps.setString(1, m.getBarcode());
                    ps.setString(2, m.getPartNumber());
                    ps.setString(3, m.getPartName());
                    ps.setBigDecimal(4, m.getCantidad());
                    ps.setString(5, m.getSimbolo());
                    ps.setString(6, m.getUbi());
                    ps.setString(7, m.getUsuarioRegistro());
                    ps.executeUpdate();
                }

                if (m.getMinimo() != null) {
                    try (PreparedStatement ps = cn.prepareStatement(sqlMinimo)) {
                        ps.setString(1, m.getBarcode());
                        ps.setBigDecimal(2, m.getMinimo());
                        ps.executeUpdate();
                    }
                }

                // La tabla Movimiento exige Cantidad > 0, por eso solo se registra si hay stock inicial
                if (m.getCantidad().signum() > 0) {
                    try (PreparedStatement ps = cn.prepareStatement(sqlMov)) {
                        ps.setString(1, m.getBarcode());
                        ps.setBigDecimal(2, m.getCantidad());
                        ps.setString(3, m.getUsuarioRegistro());
                        ps.executeUpdate();
                    }
                }
                cn.commit();
            } catch (SQLException e) {
                cn.rollback();
                throw e;
            }
        }
    }

    // Ultimos materiales registrados, con el nombre de la persona que los registro
    public List<Materialbe> listarRecientes(int cuantos) throws SQLException {
        String sql = "SELECT TOP (?) m.Barcode, m.Part_Number, m.Part_Name, m.Cantidad, m.Simbolo, m.Ubi, "
                   + "m.Fecha_Registro, m.Usuario_Registro, " + NOMBRE_PERSONAL + " AS Nombre_Registro "
                   + "FROM Material m LEFT JOIN Personal p ON p.Usuario = m.Usuario_Registro "
                   + "ORDER BY m.Fecha_Registro DESC";
        List<Materialbe> lista = new ArrayList<>();
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, cuantos);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(leer(rs, false));
                }
            }
        }
        return lista;
    }

    // Todo el stock actual (para el reporte). Incluye minimo y quien lo registro.
    public List<Materialbe> listarStock(boolean soloBajoMinimo) throws SQLException {
        String sql = "SELECT m.Barcode, m.Part_Number, m.Part_Name, m.Cantidad, m.Simbolo, m.Ubi, "
                   + "m.Fecha_Registro, m.Usuario_Registro, " + NOMBRE_PERSONAL + " AS Nombre_Registro, "
                   + "sm.Minimo "
                   + "FROM Material m "
                   + "LEFT JOIN Personal p ON p.Usuario = m.Usuario_Registro "
                   + "LEFT JOIN Stock_Minimo sm ON sm.Barcode = m.Barcode "
                   + (soloBajoMinimo ? "WHERE sm.Minimo IS NOT NULL AND m.Cantidad <= sm.Minimo " : "")
                   + "ORDER BY m.Part_Number, m.Barcode";
        List<Materialbe> lista = new ArrayList<>();
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(leer(rs, true));
            }
        }
        return lista;
    }

    // Busca un material por su codigo de barras (para la pantalla de movimientos)
    public Materialbe buscarPorBarcode(String barcode) throws SQLException {
        String sql = "SELECT m.Barcode, m.Part_Number, m.Part_Name, m.Cantidad, m.Simbolo, m.Ubi, "
                   + "m.Fecha_Registro, m.Usuario_Registro, " + NOMBRE_PERSONAL + " AS Nombre_Registro, "
                   + "sm.Minimo "
                   + "FROM Material m "
                   + "LEFT JOIN Personal p ON p.Usuario = m.Usuario_Registro "
                   + "LEFT JOIN Stock_Minimo sm ON sm.Barcode = m.Barcode "
                   + "WHERE m.Barcode = ?";
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, barcode);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? leer(rs, true) : null;
            }
        }
    }

    private Materialbe leer(ResultSet rs, boolean conMinimo) throws SQLException {
        Materialbe m = new Materialbe();
        m.setBarcode(rs.getString("Barcode"));
        m.setPartNumber(rs.getString("Part_Number"));
        m.setPartName(rs.getString("Part_Name"));
        m.setCantidad(rs.getBigDecimal("Cantidad"));
        m.setSimbolo(rs.getString("Simbolo").trim());
        m.setUbi(rs.getString("Ubi"));
        m.setFechaRegistro(rs.getTimestamp("Fecha_Registro"));
        m.setUsuarioRegistro(rs.getString("Usuario_Registro"));
        m.setNombreRegistro(rs.getString("Nombre_Registro"));
        if (conMinimo) {
            m.setMinimo(rs.getBigDecimal("Minimo"));
        }
        return m;
    }

    private String buscarTexto(String sql, String valor) throws SQLException {
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, valor);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString(1).trim();
                }
                return null;
            }
        }
    }
}
