package com.maven.dhlinvetario.dao;

import com.maven.dhlinvetario.LoginModelo.LoginConexion;
import com.maven.dhlinvetario.be.Movimientobe;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Movimientodao {

    private static final BigDecimal MAXIMO = new BigDecimal("99999999.99");

    
    public String registrar(String barcode, String tipo, BigDecimal cantidad,
                            String usuario, String motivo) throws SQLException {

        try (Connection cn = LoginConexion.getConnection()) {
            cn.setAutoCommit(false);
            try {
                BigDecimal actual;
                String sqlLeer = "SELECT Cantidad FROM Material WITH (UPDLOCK, ROWLOCK) WHERE Barcode = ?";
                try (PreparedStatement ps = cn.prepareStatement(sqlLeer)) {
                    ps.setString(1, barcode);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            cn.rollback();
                            return "noexiste";
                        }
                        actual = rs.getBigDecimal(1);
                    }
                }

                BigDecimal nuevo = "ENTRADA".equals(tipo) ? actual.add(cantidad) : actual.subtract(cantidad);
                if (nuevo.signum() < 0) {
                    cn.rollback();
                    return "stock";
                }
                if (nuevo.compareTo(MAXIMO) > 0) {
                    cn.rollback();
                    return "maximo";
                }

                try (PreparedStatement ps = cn.prepareStatement(
                        "UPDATE Material SET Cantidad = ? WHERE Barcode = ?")) {
                    ps.setBigDecimal(1, nuevo);
                    ps.setString(2, barcode);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = cn.prepareStatement(
                        "INSERT INTO Movimiento (Barcode, Tipo, Cantidad, Usuario, Motivo) VALUES (?, ?, ?, ?, ?)")) {
                    ps.setString(1, barcode);
                    ps.setString(2, tipo);
                    ps.setBigDecimal(3, cantidad);
                    ps.setString(4, usuario);
                    ps.setString(5, motivo);
                    ps.executeUpdate();
                }

                cn.commit();
                return null;
            } catch (SQLException e) {
                cn.rollback();
                throw e;
            }
        }
    }

    /**
     * Lista movimientos con filtros opcionales (los que vengan null no se aplican).
     * Siempre trae el nombre de quien hizo el movimiento.
     */
    public List<Movimientobe> listar(Date desde, Date hasta, String tipo, String barcode, int limite)
            throws SQLException {

        StringBuilder sql = new StringBuilder(
                "SELECT TOP (?) mv.Id_Movimiento, mv.Barcode, m.Part_Number, m.Part_Name, m.Simbolo, "
              + "mv.Tipo, mv.Cantidad, mv.Fecha, mv.Usuario, "
              + "(p.First_Nombre + ' ' + p.First_Apellido) AS Nombre_Usuario, mv.Motivo, "
              + "m.Usuario_Registro, (pr.First_Nombre + ' ' + pr.First_Apellido) AS Nombre_Registro "
              + "FROM Movimiento mv "
              + "JOIN Material m ON m.Barcode = mv.Barcode "
              + "LEFT JOIN Personal p ON p.Usuario = mv.Usuario "
              + "LEFT JOIN Personal pr ON pr.Usuario = m.Usuario_Registro "
              + "WHERE 1 = 1 ");

        List<Object> params = new ArrayList<>();
        params.add(limite);
        if (desde != null)   { sql.append("AND mv.Fecha >= ? ");                  params.add(desde); }
        if (hasta != null)   { sql.append("AND mv.Fecha < DATEADD(day, 1, ?) ");  params.add(hasta); }
        if (tipo != null)    { sql.append("AND mv.Tipo = ? ");                    params.add(tipo); }
        if (barcode != null) { sql.append("AND mv.Barcode = ? ");                 params.add(barcode); }
        sql.append("ORDER BY mv.Fecha DESC, mv.Id_Movimiento DESC");

        List<Movimientobe> lista = new ArrayList<>();
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                Object p = params.get(i);
                if (p instanceof Integer) {
                    ps.setInt(i + 1, (Integer) p);
                } else if (p instanceof Date) {
                    ps.setDate(i + 1, (Date) p);
                } else {
                    ps.setString(i + 1, (String) p);
                }
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Movimientobe m = new Movimientobe();
                    m.setIdMovimiento(rs.getInt("Id_Movimiento"));
                    m.setBarcode(rs.getString("Barcode"));
                    m.setPartNumber(rs.getString("Part_Number"));
                    m.setPartName(rs.getString("Part_Name"));
                    m.setSimbolo(rs.getString("Simbolo").trim());
                    m.setTipo(rs.getString("Tipo"));
                    m.setCantidad(rs.getBigDecimal("Cantidad"));
                    m.setFecha(rs.getTimestamp("Fecha"));
                    m.setUsuario(rs.getString("Usuario"));
                    m.setNombreUsuario(rs.getString("Nombre_Usuario"));
                    m.setMotivo(rs.getString("Motivo"));
                    m.setUsuarioRegistro(rs.getString("Usuario_Registro"));
                    m.setNombreRegistro(rs.getString("Nombre_Registro"));
                    lista.add(m);
                }
            }
        }
        return lista;
    }
}
