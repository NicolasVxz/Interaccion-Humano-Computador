/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.dhlinvetario.dao;

import com.maven.dhlinvetario.LoginModelo.LoginConexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Homedao {

    public int contarPartNumbers() throws SQLException {
        return numero("SELECT COUNT(DISTINCT Part_Number) FROM Material");
    }

    public int totalUnidades() throws SQLException {
        return numero("SELECT ISNULL(SUM(Cantidad), 0) FROM Material");
    }

    public int ingresosHoy() throws SQLException {
        return numero("SELECT ISNULL(SUM(Cantidad), 0) FROM Movimiento "
                    + "WHERE Tipo = 'ENTRADA' AND CAST(Fecha AS date) = CAST(GETDATE() AS date)");
    }

    public int salidasHoy() throws SQLException {
        return numero("SELECT ISNULL(SUM(Cantidad), 0) FROM Movimiento "
                    + "WHERE Tipo = 'SALIDA' AND CAST(Fecha AS date) = CAST(GETDATE() AS date)");
    }

    public List<Object[]> alertasStock() throws SQLException {
        String sql = "SELECT TOP 8 m.Part_Name, m.Cantidad, sm.Minimo "
                   + "FROM Material m JOIN Stock_Minimo sm ON sm.Barcode = m.Barcode "
                   + "WHERE m.Cantidad <= sm.Minimo ORDER BY (m.Cantidad - sm.Minimo)";
        List<Object[]> lista = new ArrayList<>();
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getString(1),
                    rs.getBigDecimal(2).stripTrailingZeros().toPlainString(),
                    rs.getBigDecimal(3).stripTrailingZeros().toPlainString()});
            }
        }
        return lista;
    }

    public List<Object[]> ultimosMovimientos() throws SQLException {
        String sql = "SELECT TOP 8 mv.Fecha, mv.Tipo, m.Part_Name, mv.Cantidad "
                   + "FROM Movimiento mv JOIN Material m ON m.Barcode = mv.Barcode "
                   + "ORDER BY mv.Fecha DESC, mv.Id_Movimiento DESC";
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm");
        List<Object[]> lista = new ArrayList<>();
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Object[]{
                    fmt.format(rs.getTimestamp(1)),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getBigDecimal(4).stripTrailingZeros().toPlainString()});
            }
        }
        return lista;
    }

    private int numero(String sql) throws SQLException {
        try (Connection cn = LoginConexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }
}
