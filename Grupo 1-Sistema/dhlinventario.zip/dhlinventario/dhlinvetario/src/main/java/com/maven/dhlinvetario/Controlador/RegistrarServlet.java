/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.maven.dhlinvetario.Controlador;

import com.maven.dhlinvetario.br.Materialbr;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "RegistrarServlet", urlPatterns = {"/RegistrarServlet"})
public class RegistrarServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!hayLogin(request)) {
            response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
            return;
        }

        if ("1".equals(request.getParameter("ok"))) {
            request.setAttribute("mensaje", "Material registrado correctamente.");
            request.setAttribute("esOk", true);
        }
        mostrar(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!hayLogin(request)) {
            response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
            return;
        }

        String error;
        try {
            Materialbr br = new Materialbr();
            error = br.registrar(
                    request.getParameter("Barcode"),
                    request.getParameter("PartNumber"),
                    request.getParameter("PartName"),
                    request.getParameter("Cantidad"),
                    request.getParameter("Simbolo"),
                    request.getParameter("Ubi"),
                    request.getParameter("Minimo"),
                    (String) request.getSession().getAttribute("usuario"));   // quien registra
        } catch (SQLException e) {
            e.printStackTrace();   
            error = "bd";
        }

        if (error == null) {
            response.sendRedirect(request.getContextPath() + "/RegistrarServlet?ok=1");
        } else {
            request.setAttribute("mensaje", textoError(error));
            request.setAttribute("esOk", false);
            mostrar(request, response);
        }
    }

    private void mostrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("recientes", new Materialbr().recientes());
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "No se pudo leer la base de datos.");
            request.setAttribute("esOk", false);
            request.setAttribute("recientes", new ArrayList<Object>());
        }
        request.getRequestDispatcher("/PAGES/registrar.jsp").forward(request, response);
    }

    private String textoError(String codigo) {
        switch (codigo) {
            case "vacio":     return "Completa todos los campos.";
            case "largo":     return "Algun campo es demasiado largo.";
            case "cantidad":  return "La cantidad no es valida (usa numeros, por ejemplo 12.5).";
            case "medida":    return "Esa unidad de medida no existe.";
            case "ubicacion": return "Esa ubicacion no existe o no esta activa.";
            case "minimo":    return "El stock minimo no es valido (usa numeros, por ejemplo 5).";
            case "sesion":    return "Tu sesion expiro. Vuelve a iniciar sesion.";
            case "dup":       return "Ese codigo de barras ya esta registrado.";
            default:          return "No se pudo guardar: error en la base de datos.";
        }
    }

    private boolean hayLogin(HttpServletRequest request) {
        HttpSession s = request.getSession(false);
        return s != null && s.getAttribute("usuario") != null;
    }
}