/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.maven.dhlinvetario.Controlador;

import com.maven.dhlinvetario.br.Homebr;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "HomeServlet", urlPatterns = {"/HomeServlet"})
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        
        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuario") == null) {
            response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
            return;
        }

        
        try {
            Homebr br = new Homebr();
            request.setAttribute("partNumbers", br.contarPartNumbers());
            request.setAttribute("totalUnidades", br.totalUnidades());
            request.setAttribute("ingresosHoy", br.ingresosHoy());
            request.setAttribute("salidasHoy", br.salidasHoy());
            request.setAttribute("alertas", br.alertas());
            request.setAttribute("movimientos", br.movimientos());
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorBD", "No se pudo leer la base de datos.");
            request.setAttribute("partNumbers", 0);
            request.setAttribute("totalUnidades", 0);
            request.setAttribute("ingresosHoy", 0);
            request.setAttribute("salidasHoy", 0);
        }

        
        request.getRequestDispatcher("/PAGES/home.jsp").forward(request, response);
    }
}