package com.maven.dhlinvetario.Controlador;

import com.maven.dhlinvetario.be.Materialbe;
import com.maven.dhlinvetario.be.Movimientobe;
import com.maven.dhlinvetario.br.Materialbr;
import com.maven.dhlinvetario.br.Movimientobr;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Reportes:
 *   ?r=stock        -> stock actual de todos los materiales
 *   ?r=bajo         -> materiales que llegaron o bajaron de su stock minimo
 *   ?r=movimientos  -> historial de entradas/salidas (filtros: desde, hasta, tipo)
 *   &csv=1          -> descarga el mismo reporte en CSV (se abre en Excel)
 */
@WebServlet(name = "ReporteServlet", urlPatterns = {"/ReporteServlet"})
public class ReporteServlet extends HttpServlet {

    private static final int LIMITE_PANTALLA = 1000;
    private static final int LIMITE_CSV = 100000;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuario") == null) {
            response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
            return;
        }

        String r = request.getParameter("r");
        if (!"bajo".equals(r) && !"movimientos".equals(r)) {
            r = "stock";
        }
        String desde = valor(request.getParameter("desde"));
        String hasta = valor(request.getParameter("hasta"));
        String tipo  = valor(request.getParameter("tipo"));
        boolean csv  = "1".equals(request.getParameter("csv"));

        try {
            if (r.equals("movimientos")) {
                List<Movimientobe> lista = new Movimientobr()
                        .listar(desde, hasta, tipo, csv ? LIMITE_CSV : LIMITE_PANTALLA);
                if (csv) {
                    csvMovimientos(response, lista);
                    return;
                }
                BigDecimal entradas = BigDecimal.ZERO;
                BigDecimal salidas = BigDecimal.ZERO;
                for (Movimientobe m : lista) {
                    if ("ENTRADA".equals(m.getTipo())) {
                        entradas = entradas.add(m.getCantidad());
                    } else {
                        salidas = salidas.add(m.getCantidad());
                    }
                }
                request.setAttribute("listaMovimientos", lista);
                request.setAttribute("totalEntradas", entradas);
                request.setAttribute("totalSalidas", salidas);
                request.setAttribute("truncado", lista.size() >= LIMITE_PANTALLA);
            } else {
                List<Materialbe> lista = new Materialbr().stock(r.equals("bajo"));
                if (csv) {
                    csvStock(response, lista, r);
                    return;
                }
                request.setAttribute("listaStock", lista);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            if (csv) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error en la base de datos");
                return;
            }
            request.setAttribute("mensaje", "No se pudo leer la base de datos.");
            request.setAttribute("listaStock", new ArrayList<Materialbe>());
            request.setAttribute("listaMovimientos", new ArrayList<Movimientobe>());
            request.setAttribute("totalEntradas", BigDecimal.ZERO);
            request.setAttribute("totalSalidas", BigDecimal.ZERO);
        }

        request.setAttribute("reporte", r);
        request.setAttribute("fDesde", desde);
        request.setAttribute("fHasta", hasta);
        request.setAttribute("fTipo", tipo);
        request.getRequestDispatcher("/PAGES/reportes.jsp").forward(request, response);
    }

    // ---------- CSV ----------

    private void csvStock(HttpServletResponse response, List<Materialbe> lista, String r) throws IOException {
        PrintWriter out = abrirCsv(response, r.equals("bajo") ? "stock_bajo" : "stock_actual");
        out.print("Codigo de barras;Part Number;Material;Cantidad;Unidad;Ubicacion;Stock minimo;Registrado por;Fecha de registro\r\n");
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        for (Materialbe m : lista) {
            out.print(csv(m.getBarcode()) + ";" + csv(m.getPartNumber()) + ";" + csv(m.getPartName()) + ";"
                    + num(m.getCantidad()) + ";" + csv(m.getSimbolo()) + ";" + csv(m.getUbi()) + ";"
                    + num(m.getMinimo()) + ";" + csv(nombre(m.getNombreRegistro(), m.getUsuarioRegistro())) + ";"
                    + fmt.format(m.getFechaRegistro()) + "\r\n");
        }
        out.flush();
    }

    private void csvMovimientos(HttpServletResponse response, List<Movimientobe> lista) throws IOException {
        PrintWriter out = abrirCsv(response, "movimientos");
        out.print("Fecha;Tipo;Codigo de barras;Part Number;Material;Cantidad;Unidad;Movimiento por;Registrado por;Motivo\r\n");
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        for (Movimientobe m : lista) {
            out.print(fmt.format(m.getFecha()) + ";" + csv(m.getTipo()) + ";" + csv(m.getBarcode()) + ";"
                    + csv(m.getPartNumber()) + ";" + csv(m.getPartName()) + ";" + num(m.getCantidad()) + ";"
                    + csv(m.getSimbolo()) + ";" + csv(nombre(m.getNombreUsuario(), m.getUsuario())) + ";"
                    + csv(nombre(m.getNombreRegistro(), m.getUsuarioRegistro())) + ";"
                    + csv(m.getMotivo()) + "\r\n");
        }
        out.flush();
    }

    private PrintWriter abrirCsv(HttpServletResponse response, String nombre) throws IOException {
        response.setContentType("text/csv; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + nombre + ".csv\"");
        PrintWriter out = response.getWriter();
        out.print('\uFEFF');   // BOM: para que Excel respete las tildes
        return out;
    }

    // Separador ";" (Excel en espanol/Peru). Se entrecomilla y se evita que Excel ejecute formulas.
    private String csv(String s) {
        if (s == null) {
            return "";
        }
        if (!s.isEmpty() && "=+-@".indexOf(s.charAt(0)) >= 0) {
            s = "'" + s;
        }
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private String num(BigDecimal n) {
        return n == null ? "" : n.stripTrailingZeros().toPlainString();
    }

    private String nombre(String nombre, String usuario) {
        return nombre != null ? nombre : usuario;
    }

    private String valor(String s) {
        return s == null ? "" : s.trim();
    }
}
