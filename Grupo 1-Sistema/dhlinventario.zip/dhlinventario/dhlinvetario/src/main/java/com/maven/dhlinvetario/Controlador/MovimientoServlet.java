package com.maven.dhlinvetario.Controlador;

import com.maven.dhlinvetario.be.Materialbe;
import com.maven.dhlinvetario.br.Movimientobr;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "MovimientoServlet", urlPatterns = {"/MovimientoServlet"})
public class MovimientoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!hayLogin(request)) {
            response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
            return;
        }

        
        if ("1".equals(request.getParameter("ok"))) {
            String mensaje = "Movimiento registrado correctamente.";
            try {
                Materialbe m = new Movimientobr().buscarMaterial(request.getParameter("barcode"));
                if (m != null) {
                    mensaje += " Stock actual de " + m.getPartName() + ": "
                            + m.getCantidad().stripTrailingZeros().toPlainString() + " " + m.getSimbolo() + ".";
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("esOk", true);
        }
        mostrar(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!hayLogin(request)) {
            response.sendRedirect(request.getContextPath() + "/PAGES/login.jsp");
            return;
        }

        String barcode = request.getParameter("Barcode");
        String error;
        try {
            error = new Movimientobr().registrar(
                    barcode,
                    request.getParameter("Tipo"),
                    request.getParameter("Cantidad"),
                    request.getParameter("Motivo"),
                    (String) request.getSession().getAttribute("usuario"));   // quien hace el movimiento
        } catch (SQLException e) {
            e.printStackTrace();
            error = "bd";
        }

        if (error == null) {
            String b = URLEncoder.encode(barcode.trim(), StandardCharsets.UTF_8);
            response.sendRedirect(request.getContextPath() + "/MovimientoServlet?ok=1&barcode=" + b);
        } else {
            request.setAttribute("mensaje", textoError(error));
            request.setAttribute("esOk", false);
            mostrar(request, response);
        }
    }

    private void mostrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("movimientos", new Movimientobr().recientes());
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "No se pudo leer la base de datos.");
            request.setAttribute("esOk", false);
            request.setAttribute("movimientos", new ArrayList<Object>());
        }
        request.getRequestDispatcher("/PAGES/movimientos.jsp").forward(request, response);
    }

    private String textoError(String codigo) {
        switch (codigo) {
            case "vacio":    return "Completa todos los campos.";
            case "tipo":     return "El tipo debe ser ENTRADA o SALIDA.";
            case "cantidad": return "La cantidad no es valida (debe ser mayor a 0, por ejemplo 12.5).";
            case "largo":    return "El codigo o el motivo es demasiado largo.";
            case "noexiste": return "Ese codigo de barras no esta registrado. Registralo primero en REGISTRAR.";
            case "stock":    return "Stock insuficiente: la salida es mayor a lo que hay disponible.";
            case "maximo":   return "La entrada supera la cantidad maxima permitida.";
            case "sesion":   return "Tu sesion expiro. Vuelve a iniciar sesion.";
            default:         return "No se pudo guardar: error en la base de datos.";
        }
    }

    private boolean hayLogin(HttpServletRequest request) {
        HttpSession s = request.getSession(false);
        return s != null && s.getAttribute("usuario") != null;
    }
}
