CREATE DATABASE DHL_INVENTARIO_BD
ON
PRIMARY (NAME = DHL_INVENTARIO_BD_MDF,
FILENAME='C:\DHL-INVENTARIO\DHL_INVENTARIO_BD\DHL_INVENTARIO_BD.MDF',
SIZE= 500MB,
MAXSIZE= 50GB,
FILEGROWTH= 128MB)
LOG ON (
NAME = DHL_INVENTARIO_BD_LDF,
FILENAME='C:\DHL-INVENTARIO\DHL_INVENTARIO_BD\DHL_INVENTARIO_BD.LDF',
SIZE= 250MB,
MAXSIZE= 20GB,
FILEGROWTH= 70MB)
GO
 

use  DHL_INVENTARIO_BD

CREATE TABLE Personal (
Usuario VARCHAR(25) NOT NULL PRIMARY KEY,
First_Nombre VARCHAR(25) NOT NULL,
Second_Nombre VARCHAR(25) NULL,
First_Apellido VARCHAR(25) NOT NULL,
Second_Apellido VARCHAR(25) NOT NULL,
Clave VARCHAR(20) NOT NULL,
Correo VARCHAR(100) NOT NULL,
Telefono VARCHAR(9) NOT NULL
);
GO
 
CREATE TABLE Ubicacion (
Ubi VARCHAR(25) NOT NULL PRIMARY KEY,
Descripcion VARCHAR(100) NOT NULL,
Estado VARCHAR(15) NOT NULL
);
GO
 
CREATE TABLE Medida (
Simbolo CHAR(5) NOT NULL PRIMARY KEY,
Comentario VARCHAR(25) NOT NULL
);
GO
 
CREATE TABLE Material (
Barcode VARCHAR(50) NOT NULL PRIMARY KEY,
Part_Number VARCHAR(50) NOT NULL,
Part_Name VARCHAR(120) NOT NULL,
Cantidad DECIMAL(10,2) NOT NULL CHECK (Cantidad >= 0),
Simbolo CHAR(5) NOT NULL,
Ubi VARCHAR(25) NOT NULL,
Fecha_Registro DATETIME NOT NULL DEFAULT GETDATE(),
Usuario_Registro VARCHAR(25) NOT NULL,
 
CONSTRAINT FK_Material_Medida FOREIGN KEY (Simbolo) REFERENCES Medida(Simbolo),
CONSTRAINT FK_Material_Ubicacion FOREIGN KEY (Ubi) REFERENCES Ubicacion(Ubi),
CONSTRAINT FK_Material_Personal FOREIGN KEY (Usuario_Registro) REFERENCES Personal(Usuario)
);
GO
 
CREATE TABLE Movimiento (
Id_Movimiento INT IDENTITY(1,1) PRIMARY KEY,
Barcode VARCHAR(50) NOT NULL,
Tipo VARCHAR(10) NOT NULL CHECK (Tipo IN ('ENTRADA','SALIDA')),
Cantidad DECIMAL(10,2) NOT NULL CHECK (Cantidad > 0),
Fecha DATETIME NOT NULL DEFAULT GETDATE(),
Usuario VARCHAR(25) NOT NULL,        
Motivo VARCHAR(200) NOT NULL,
 
CONSTRAINT FK_Movimiento_Material FOREIGN KEY (Barcode) REFERENCES Material(Barcode),
CONSTRAINT FK_Movimiento_Personal FOREIGN KEY (Usuario) REFERENCES Personal(Usuario)
);
GO
 
CREATE TABLE Stock_Minimo (
Barcode VARCHAR(50) NOT NULL PRIMARY KEY,
Minimo DECIMAL(10,2) NOT NULL CHECK (Minimo >= 0),
 
CONSTRAINT FK_StockMinimo_Material FOREIGN KEY (Barcode) REFERENCES Material(Barcode)
);
GO

 
INSERT INTO Medida (Simbolo, Comentario)
VALUES ('EA','UNIDAD'), ('G','GRAMOS');
 
INSERT INTO Ubicacion (Ubi, Descripcion, Estado)
VALUES ('AP/A1-01-1','GAVETA','ACTIVO'),
       ('AP/A2-05-9','ANAQUEL','ACTIVO');
 
INSERT INTO Personal (Usuario, First_Nombre, Second_Nombre, First_Apellido, Second_Apellido, Clave, Correo, Telefono)
VALUES ('4005000', 'Max','Castillo','Ruso','Klaz','0000', 'prueba@gmail.com',  '999999999'),
       ('4863355', 'Joseph','Maximo','Aguero','Vargas','1919', 'joseph@gmail.com','940323557');

INSERT INTO Material (Barcode, Part_Number, Part_Name, Cantidad, Simbolo, Ubi, Usuario_Registro)
VALUES ('7750001', 'PN-1001', 'Filtro de aceite', 20, 'EA', 'AP/A1-01-1', '4005000'),
       ('7750002', 'PN-2002', 'Grasa industrial', 500, 'G', 'AP/A2-05-9', '4863355');
 
INSERT INTO Movimiento (Barcode, Tipo, Cantidad, Usuario, Motivo)
VALUES ('7750001', 'ENTRADA', 20,  '4005000', 'Registro inicial'),
       ('7750002', 'ENTRADA', 500, '4863355', 'Registro inicial');
 
INSERT INTO Stock_Minimo (Barcode, Minimo)
VALUES ('7750001', 5),
       ('7750002', 100);
GO
 
SELECT*FROM Material
SELECT*FROM Medida
SELECT*FROM Movimiento
SELECT*FROM Personal
SELECT*FROM Stock_Minimo
SELECT*FROM Ubicacion

